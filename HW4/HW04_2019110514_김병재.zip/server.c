#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sys/types.h>

#define PORT 12345


pthread_mutex_t player1, player2; // 뮤텍스를 활용하지 못하였으나 일단 그대로 뒀습니다.
int client_socket1, client_socket2; // 클라이언트 소켓 변수
char choice1[100]; // 클라이언트1 입력값
char choice2[100]; //클라이언트 2 입력값
char* intro1 = "\n\n당신은 player1입니다.";
char* intro2 = "\n\n당신은 player2입니다.";

// 클라이언트1에게 문자열을 보내는 함수
void msgsend1(char* msg) {
    if (send(client_socket1, msg, strlen(msg), 0) == -1) {
        perror("데이터 전송 실패");
        exit(1);
    }
}

// 클라이언트2에게 문자열을 보내는 함수

void msgsend2(char* msg) {
    if (send(client_socket2, msg, strlen(msg), 0) == -1) {
        perror("데이터 전송 실패");
        exit(1);
    }
}


// 가위바위보 결과를 계산하는 함수
char* rsp(char* choice1, char* choice2) {
    if ( (strcmp(choice1,"q") == 0) || (strcmp(choice2,"q") ==0) ) {
       printf("게임이 종료되었습니다.\n");
       exit(0);
    } else if (strcmp(choice1, choice2) == 0) {
        return "무승부";
    } else if (
        (strcmp(choice1, "가위") == 0 && strcmp(choice2, "보") == 0)
        || (strcmp(choice1, "바위") == 0 && strcmp(choice2, "가위") == 0)
        || (strcmp(choice1, "보") == 0 && strcmp(choice2, "바위") == 0)
    ) {
        return "Player 1 승리";
    } else {
        return "Player 2 승리";
    }
}
/*
// 클라이언트로부터 값을 전달받는 함수(스레드를 만들어서 실행하려 하였으나 오류 발생)

void* client1 () {
    pthread_mutex_lock(&player1);
    memset(choice1, 0, sizeof(choice1));
    if (recv(client_socket1, choice1, sizeof(choice1), 0) <= 0) {
        perror("데이터 수신 실패");
        exit(1);
    }
    printf("Player 1 선택: %s\n", choice1);
    pthread_mutex_unlock(&player2);
}

void* client2 () {
    pthread_mutex_lock(&player2);
    memset(choice2, 0, sizeof(choice2));
    if (recv(client_socket2, choice2, sizeof(choice2), 0) <= 0) {
        perror("데이터 수신 실패");
        exit(1);
    }
    printf("Player 2 선택: %s\n", choice2);
    pthread_mutex_unlock(&player1);
}*/

int main() {
    int server_socket;
    struct sockaddr_in server_address, client_address;
    socklen_t client_address_length;

    // 소켓 생성
    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket == -1) {
        perror("소켓 생성 실패");
        exit(1);
    }

    // 주소 설정
    server_address.sin_family = AF_INET;
    server_address.sin_addr.s_addr = htonl(INADDR_ANY);
    server_address.sin_port = htons(PORT);

    // 바인딩
    if (bind(server_socket, (struct sockaddr*)&server_address, sizeof(server_address)) == -1) {
        perror("바인딩 실패");
        exit(1);
    }

    printf("가위바위보 게임 서버입니다.\n");
    printf("클라이언트를 기다리는 중...\n");

   // 클라이언트 대기열 설정
    if (listen(server_socket, 2) == -1) {
        perror("대기열 설정 실패");
        exit(1);
    }


    // 첫 번째 클라이언트 접속
    client_address_length = sizeof(client_address);
    client_socket1 = accept(server_socket, (struct sockaddr*)&client_address, &client_address_length);
    if (client_socket1 == -1) {
        perror("첫 번째 클라이언트 접속 실패");
        exit(1);
    }
    printf("첫 번째 클라이언트가 접속하였습니다.\n");

    // 두 번째 클라이언트 접속
    client_socket2 = accept(server_socket, (struct sockaddr*)&client_address, &client_address_length);
    if (client_socket2 == -1) {
        perror("두 번째 클라이언트 접속 실패");
        exit(1);
    }
    printf("두 번째 클라이언트가 접속하였습니다.\n");

 
            
    // 가위바위보 게임 진행
    while (1) {
    /*
        pthread_t thread1, thread2;
        if (pthread_create(&thread1, NULL, client1, NULL) != 0) {
            perror("클라이언트 1 스레드 생성 실패");
        exit(1);
    }

    // 클라이언트 2 스레드 생성
    
    if (pthread_create(&thread2, NULL, client2, NULL) != 0) {
        perror("클라이언트 2 스레드 생성 실패");
        exit(1);
    }*/


        // 클라이언트1의 수신
        memset(choice1, 0, sizeof(choice1));
        pthread_mutex_lock(&player1);
        if (recv(client_socket1, choice1, sizeof(choice1), 0) <= 0) {
            perror("수신 실패");
            exit(1);
        }
        printf("Player1 : %s\n", choice1);
        pthread_mutex_unlock(&player1);
        
            

        // 클라이언트2의 수신
        memset(choice2, 0, sizeof(choice2));
        pthread_mutex_lock(&player1);
        if (recv(client_socket2, choice2, sizeof(choice2), 0) <= 0) {
           perror("수신 실패");
           exit(1);
        }
        printf("Player2 : %s\n", choice2);
        pthread_mutex_unlock(&player1);
       

        // 선택이 모두 완료되면
        if (strlen(choice1) > 0 && strlen(choice2) > 0) {
            // 게임 결과 계산
            char* result = rsp(choice1, choice2);
            printf("게임 결과: %s\n", result);

            // 결과 전송
            msgsend1(result);
            msgsend2(result);
            
            
            // 선택 초기화
            memset(choice1, 0, sizeof(choice1));
            memset(choice2, 0, sizeof(choice2));

            //메시지 전송
            msgsend1(intro1);
            msgsend2(intro2);
            
        }
    }

    // 소켓 종료
    close(client_socket1);
    close(client_socket2);
    close(server_socket);

    return 0;
}


