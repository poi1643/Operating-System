#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define SERVER_IP "127.0.0.1"
#define PORT 12345

int main() {
    int client_socket;
    struct sockaddr_in server_address;
    char result[100];
    char choice[100];

    // 클라이언트 소켓 생성
    client_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (client_socket == -1) {
        perror("소켓 생성 실패");
        exit(1);
    }

    // 서버 주소 설정
    server_address.sin_family = AF_INET;
    server_address.sin_addr.s_addr = inet_addr(SERVER_IP);
    server_address.sin_port = htons(PORT);

    // 서버에 연결
    if (connect(client_socket, (struct sockaddr*)&server_address, sizeof(server_address)) == -1) {
        perror("서버 연결 실패");
        exit(1);
    }

    printf("가위바위보 게임입니다.\n");

    // 가위바위보 입력
    while (1) {
        printf("가위, 바위, 보 중 하나를 선택하세요(종료 : q) : ");
        fgets(choice, 100, stdin);
        choice[strcspn(choice, "\n")] = '\0'; // 개행 문자 제거

        
        // 전송
        if (send(client_socket, choice, strlen(choice), 0) == -1) {
            perror("데이터 전송 실패");
            exit(1);
        }
        
        // 입력이 q라면 프로그램 종료
        if (strcmp(choice, "q") == 0) {
            printf("게임을 종료합니다.\n");
            break;
        }

        // 결과 수신
        memset(result, 0, sizeof(result));
        if (recv(client_socket, result, sizeof(result), 0) <= 0) {
            perror("데이터 수신 실패");
            exit(1);
        }
        printf("\n게임 결과: %s\n", result);  
    }

    // 소켓 종료
    close(client_socket);

    return 0;
}

